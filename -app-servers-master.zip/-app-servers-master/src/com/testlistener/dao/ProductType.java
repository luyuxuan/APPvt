package com.testlistener.dao;

public class ProductType {

}

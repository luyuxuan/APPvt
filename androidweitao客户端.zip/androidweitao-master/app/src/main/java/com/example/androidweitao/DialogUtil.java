package com.example.androidweitao;

import android.view.View.OnClickListener;

public class DialogUtil {
	
	public static void showDialog(Login login, String string, boolean b) {
		// TODO Auto-generated method stub
		
	}

	public static void showDialog(OnClickListener onClickListener,
			String string, boolean b) {
		// TODO Auto-generated method stub
		
	}

}

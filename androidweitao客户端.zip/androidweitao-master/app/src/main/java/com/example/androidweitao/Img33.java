package com.example.androidweitao;

import android.app.Activity;
import android.os.Bundle;

public class Img33 extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.img33);
		
	}

}

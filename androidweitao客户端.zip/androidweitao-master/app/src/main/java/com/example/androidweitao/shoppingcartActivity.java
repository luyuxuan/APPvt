package com.example.androidweitao;

import android.app.Activity;

public class shoppingcartActivity extends Activity {

}
